package repository;

import domain.Sectie;

public interface SectieRepository extends CrudRepository<Integer, Sectie>{
}
