package repository;

import domain.CadruMedical;
import domain.Sectie;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class SectieRepositoryHibernate implements SectieRepository{
    @Override
    public Sectie findOne(Integer id) throws IllegalArgumentException {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from Sectie where idSectie=:id");
            query.setParameter("id", id);
            Sectie sectie= (Sectie) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  sectie;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }

    @Override
    public Iterable<Sectie> findAll() {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            //Query query=session.createQuery("from "Angajat" ");
            //List<Angajat> angajati= query.getResultList();
            List<Sectie> sectii =
                    session.createQuery("from Sectie", Sectie.class)
                            .list();
            session.getTransaction().commit();
            close();
            return  sectii;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }


    @Override
    public void save(Sectie entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Sectie sectie = new Sectie(entity.getNrCadreMedicale(), entity.getCapacitate(), entity.getNume());
                session.save(sectie);
                tx.commit();
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(Sectie e) {

    }

    static SessionFactory sessionFactory;
    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }
}
