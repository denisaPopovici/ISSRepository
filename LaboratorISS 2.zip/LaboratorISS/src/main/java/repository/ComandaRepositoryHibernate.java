package repository;

import domain.CadruMedical;
import domain.Comanda;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class ComandaRepositoryHibernate implements ComandaRepository{
    @Override
    public Comanda findOne(Integer id) throws IllegalArgumentException {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from Comanda where idComanda=:id");
            query.setParameter("id", id);
            Comanda comanda= (Comanda) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  comanda;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }

    @Override
    public Iterable<Comanda> findAll() {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();

            List<Comanda> comenzi =
                    session.createQuery("from Comanda", Comanda.class)
                            .list();
            session.getTransaction().commit();
            close();
            return  comenzi;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }


    @Override
    public void save(Comanda entity) {
        initialize();
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Comanda comanda = new Comanda(entity.getData(), entity.getStatus(), entity.getCantitate(), entity.getDescriere(),entity.getIdMedicament(), entity.getIdSectie());
                session.save(comanda);
                tx.commit();
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(Comanda e) {

    }

    static SessionFactory sessionFactory;
    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }
}
