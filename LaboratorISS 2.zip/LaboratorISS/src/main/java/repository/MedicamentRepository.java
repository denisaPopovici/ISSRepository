package repository;

import domain.Medicament;

public interface MedicamentRepository extends CrudRepository<Integer, Medicament> {
}
