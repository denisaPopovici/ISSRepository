package repository;

import domain.Farmacist;

import java.util.List;
public interface FarmacistRepository extends CrudRepository<Integer, Farmacist> {

}