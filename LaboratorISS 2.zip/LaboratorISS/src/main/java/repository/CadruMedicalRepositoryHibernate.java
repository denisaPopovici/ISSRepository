package repository;

import domain.CadruMedical;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class CadruMedicalRepositoryHibernate implements CadruMedicalRepository{
    @Override
    public CadruMedical findOne(Integer id) throws IllegalArgumentException {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from CadruMedical where idPersonalMedical=:id");
            query.setParameter("id", id);
            CadruMedical cadruMedical= (CadruMedical) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  cadruMedical;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }

    @Override
    public Iterable<CadruMedical> findAll() {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            //Query query=session.createQuery("from "Angajat" ");
            //List<Angajat> angajati= query.getResultList();
            List<CadruMedical> cadre =
                    session.createQuery("from CadruMedical", CadruMedical.class)
                            .list();
            session.getTransaction().commit();
            close();
            return  cadre;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }


    @Override
    public void save(CadruMedical entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                CadruMedical cadruMedical = new CadruMedical(entity.getNume(), entity.getUsername(), entity.getParola(), entity.getDataNasterii(), entity.getIdSectie());
                session.save(cadruMedical);
                tx.commit();
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(CadruMedical e) {

    }

    static SessionFactory sessionFactory;
    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }
}
