import domain.Farmacie;
import domain.Farmacist;
import repository.FarmacieRepository;
import repository.FarmacieRepositoryHibernate;
import repository.FarmacistRepository;
import repository.FarmacistRepositoryHibernate;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        MainFX.launch(args);

    }
}
