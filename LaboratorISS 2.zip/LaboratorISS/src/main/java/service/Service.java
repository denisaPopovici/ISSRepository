package service;

import domain.*;
import repository.*;
import utils.observer.Observable;
import utils.observer.Observer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Service implements IService, Observable {
    private CadruMedicalRepository cadruMedicalRepository;
    private ComandaRepository comandaRepository;
    private FarmacieRepository farmacieRepository;
    private FarmacistRepository farmacistRepository;
    private MedicamentRepository medicamentRepository;
    private SectieRepository sectieRepository;
    private StocItemRepository stocItemRepository;

    public Service(CadruMedicalRepository cadruMedicalRepository, ComandaRepository comandaRepository,  FarmacieRepository farmacieRepository, FarmacistRepository farmacistRepository, MedicamentRepository medicamentRepository, SectieRepository sectieRepository, StocItemRepository stocItemRepository) {
        this.cadruMedicalRepository = cadruMedicalRepository;
        this.comandaRepository = comandaRepository;
        this.farmacieRepository = farmacieRepository;
        this.farmacistRepository = farmacistRepository;
        this.medicamentRepository = medicamentRepository;
        this.sectieRepository = sectieRepository;
        this.stocItemRepository = stocItemRepository;
    }

    @Override
    public Farmacist getFarmacistByUsernameAndPassword(String username, String parola) {
        for(Farmacist farmacist: farmacistRepository.findAll()){
            if(farmacist.getUsername().compareTo(username)==0 && farmacist.getParola().compareTo(parola)==0)
                return farmacist;
        }
        return null;
    }

    @Override
    public CadruMedical getCadruMedicalByUsernameAndPassword(String username, String parola) {
        for(CadruMedical cadruMedical: cadruMedicalRepository.findAll()){
            if(cadruMedical.getUsername().compareTo(username)==0 && cadruMedical.getParola().compareTo(parola)==0)
                return cadruMedical;
        }
        return null;
    }

    @Override
    public Iterable<Medicament> getAllMedicamente() {
        return medicamentRepository.findAll();
    }

    @Override
    public Iterable<Comanda> getAllComenzi() {
        for(Comanda c:comandaRepository.findAll()){
            System.out.println(c.getStatus());
        }
        return comandaRepository.findAll();
    }

    @Override
    public void addComanda(Medicament medicament, int cantitate, String descriere, Integer idSectie) {
        Comanda comanda=new Comanda(LocalDate.now().toString(), "In asteptare", cantitate, descriere, medicament.getId(), idSectie);
        comandaRepository.save(comanda);

    }

    @Override
    public Medicament findMedicament(Integer id) {
        return medicamentRepository.findOne(id);
    }
    private List<Observer> observers=new ArrayList<>();

    @Override
    public void addObserver(Observer e) {
        observers.add(e);

    }

    @Override
    public void removeObserver(Observer e) {
        observers.remove(e);
    }

    @Override
    public void notifyObservers() {
        observers.stream().forEach(x->x.update());
    }

}
