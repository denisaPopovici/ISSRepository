package service;

import domain.CadruMedical;
import domain.Comanda;
import domain.Farmacist;
import domain.Medicament;

import java.util.List;

public interface IService {
    public Farmacist getFarmacistByUsernameAndPassword(String username, String parola);

    public CadruMedical getCadruMedicalByUsernameAndPassword(String username, String parola);

    public Iterable<Medicament> getAllMedicamente();

    public Iterable<Comanda> getAllComenzi();

    public void addComanda(Medicament medicament, int cantitate, String descriere, Integer idSectie);

    public Medicament findMedicament(Integer id);


}
