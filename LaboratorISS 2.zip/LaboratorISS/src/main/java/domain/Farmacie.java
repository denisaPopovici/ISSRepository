package domain;

public class Farmacie extends Entity<Integer>{

    private String nume;
    private int nrAngajati;

    public Farmacie(){

    }

    public Farmacie(String nume, int nrAngajati) {
        this.nume = nume;
        this.nrAngajati = nrAngajati;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getNrAngajati() {
        return nrAngajati;
    }

    public void setNrAngajati(int nrAngajati) {
        this.nrAngajati = nrAngajati;
    }

    @Override
    public String toString() {
        return "Farmacie{" + "id='" + getId()+ '\''+
                ", nume='" + nume + '\'' +
                ", nrAngajati='" + nrAngajati + '\'' +
                '}';
    }
}
