package domain;

public class Sectie extends Entity<Integer>{
    private int nrCadreMedicale;
    private int capacitate;
    private String nume;

    public Sectie(){}

    public Sectie(int nrCadreMedicale, int capacitate, String nume) {
        this.nrCadreMedicale = nrCadreMedicale;
        this.capacitate = capacitate;
        this.nume = nume;
    }

    public int getNrCadreMedicale() {
        return nrCadreMedicale;
    }

    public void setNrCadreMedicale(int nrCadreMedicale) {
        this.nrCadreMedicale = nrCadreMedicale;
    }

    public int getCapacitate() {
        return capacitate;
    }

    public void setCapacitate(int capacitate) {
        this.capacitate = capacitate;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    @Override
    public String toString() {
        return "Sectie{" + "id='" + getId()+ '\''+
                ", nume='" + nume + '\'' +
                ", nrCadreMedicale='" + nrCadreMedicale + '\'' +
                ", capacitate='" + capacitate + '\'' +
                '}';
    }
}
