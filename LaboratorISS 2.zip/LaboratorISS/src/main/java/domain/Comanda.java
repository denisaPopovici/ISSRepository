package domain;

public class Comanda extends Entity<Integer>{
    private String data;
    private String status;
    private int cantitate;
    private String descriere;
    private Integer idMedicament;
    private Integer idSectie;

    public int getCantitate() {
        return cantitate;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public Integer getIdMedicament() {
        return idMedicament;
    }

    public void setIdMedicament(Integer idMedicament) {
        this.idMedicament = idMedicament;
    }

    public Integer getIdSectie() {
        return idSectie;
    }

    public void setIdSectie(Integer idSectie) {
        this.idSectie = idSectie;
    }

    public Comanda(String data, String status, int cantitate, String descriere, Integer idMedicament, Integer idSectie) {
        this.data = data;
        this.status = status;
        this.cantitate = cantitate;
        this.descriere = descriere;
        this.idMedicament = idMedicament;
        this.idSectie = idSectie;
    }

    public Comanda(){}

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Comanda{" + "id='" + getId()+ '\''+
                ", data='" + data + '\'' +
                ", status='" + status + '\'' +
                ", cantitate='" + cantitate + '\'' +
                ", descriere='" + descriere + '\'' +
                ", idMedicament='" + idMedicament + '\'' +
                ", idSectie='" + idSectie + '\'' +
                '}';
    }
}
