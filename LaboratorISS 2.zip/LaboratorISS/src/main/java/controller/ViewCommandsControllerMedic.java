package controller;

import domain.CadruMedical;
import domain.DTO;
import domain.Entity;
import domain.Medicament;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import service.Service;
import utils.observer.Observer;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ViewCommandsControllerMedic implements Observer {
    private Service service;
    private CadruMedical currentUser;

    public void setService(Service service) {
        this.service=service;
        initModel();
        service.addObserver(this);
    }
    public void setCurrentUser(CadruMedical currentUser){
        this.currentUser=currentUser;
    }
    ObservableList<DTO> model = FXCollections.observableArrayList();

    @FXML
    TableView<DTO> tableView;
    @FXML
    TableColumn<DTO, String> tableColumnData;
    @FXML
    TableColumn<DTO, String> tableColumnStatus;
    @FXML
    TableColumn<DTO, Integer> tableColumnCantitate;
    @FXML
    TableColumn<DTO, String> tableColumnDescriere;
    @FXML
    TableColumn<DTO, String> tableColumnMedicament;

    @FXML
    public void initialize() {
        tableColumnData.setCellValueFactory(new PropertyValueFactory<DTO, String>("data"));
        tableColumnStatus.setCellValueFactory(new PropertyValueFactory<DTO, String>("status"));
        tableColumnCantitate.setCellValueFactory(new PropertyValueFactory<DTO, Integer>("cantitate"));
        tableColumnDescriere.setCellValueFactory(new PropertyValueFactory<DTO, String>("descriere"));
        tableColumnMedicament.setCellValueFactory(new PropertyValueFactory<DTO, String>("medicament"));

        tableView.setItems(model);
    }

    private void initModel() {
        System.out.println(currentUser);
        List<DTO> list = StreamSupport.stream(service.getAllComenzi().spliterator(), false)
                .filter(x -> (x.getIdSectie() == currentUser.getIdSectie()))
                .map(x->{
                    DTO dto=new DTO(x.getData(),x.getStatus(),x.getCantitate(),x.getDescriere(),service.findMedicament(x.getIdMedicament()).getNume());
                    return dto;})
                .collect(Collectors.toList());
        model.setAll(list);

    }

    @FXML
    public void anuleazaComanda(){
        MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Succes!","Comanda anulata cu succes!");

    }

    @Override
    public void update() {
        initModel();
    }
}
