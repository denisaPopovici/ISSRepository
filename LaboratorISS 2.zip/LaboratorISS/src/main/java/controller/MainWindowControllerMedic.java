package controller;

import domain.CadruMedical;
import domain.Entity;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import service.Service;

import java.io.IOException;

public class MainWindowControllerMedic {
    private Service service;
    private CadruMedical currentUser;

    public void setService(Service service) {
        this.service=service;
    }
    public void setCurrentUser(CadruMedical currentUser){
        this.currentUser=currentUser;
    }

    @FXML
    private void initialize() {
    }

    @FXML
    public void vizualizeazaComenzi() {
        try {

            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/views/CommandsMedicView.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            ViewCommandsControllerMedic mainController = loader.getController();
            mainController.setCurrentUser(currentUser);

            mainController.setService(service);
            System.out.println("Current user in main: "+currentUser);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void plaseazaComanda() {
        try {

            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/views/MakeOrderView.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            MakeOrderController mainController = loader.getController();
            mainController.setCurrentUser(currentUser);
            mainController.setService(service);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
