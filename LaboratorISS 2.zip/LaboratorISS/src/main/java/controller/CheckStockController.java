package controller;

import domain.Entity;
import javafx.fxml.FXML;
import service.Service;

public class CheckStockController {
    private Service service;
    private Entity<Integer> currentUser;
    public void setService(Service service) {
        this.service=service;
    }
    public void setCurrentUser(Entity<Integer> currentUser){
        this.currentUser=currentUser;
    }

    @FXML
    private void initialize() {
    }
}
