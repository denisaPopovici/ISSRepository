package controller;

import domain.CadruMedical;
import domain.Entity;
import domain.Medicament;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import service.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MakeOrderController {
    private Service service;
    private CadruMedical currentUser;
    public void setService(Service service) {
        this.service=service;
        initModel();
    }
    public void setCurrentUser(CadruMedical currentUser){
        this.currentUser=currentUser;
    }
    @FXML
    private TextField textFieldCantitate;
    @FXML
    private TextField textFieldDescriere;

    ObservableList<Medicament> model = FXCollections.observableArrayList();

    @FXML
    TableView<Medicament> tableView;
    @FXML
    TableColumn<Medicament, String> tableColumnNume;
    @FXML
    TableColumn<Medicament, Float> tableColumnPret;
    @FXML
    TableColumn<Medicament, String> tableColumnCompanie;
    @FXML
    TableColumn<Medicament, Integer> tableColumnEficacitate;


    private void initModel() {

        List<Medicament> list = StreamSupport.stream(service.getAllMedicamente().spliterator(), false)
                .collect(Collectors.toList());
        model.setAll(list);

    }

    @FXML
    public void initialize() {
        tableColumnNume.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nume"));
        tableColumnPret.setCellValueFactory(new PropertyValueFactory<Medicament, Float>("pret"));
        tableColumnCompanie.setCellValueFactory(new PropertyValueFactory<Medicament, String>("companie"));
        tableColumnEficacitate.setCellValueFactory(new PropertyValueFactory<Medicament, Integer>("eficacitate"));
        tableView.setItems(model);
    }

    @FXML
    public void ok(){
        //salvam comanda
        try{
            service.addComanda(tableView.getSelectionModel().getSelectedItem(),Integer.parseInt(textFieldCantitate.getText().toString()),textFieldDescriere.getText().toString(),currentUser.getIdSectie());
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Felicitari!","Comanda realizata cu succes!");
        }
        catch (Exception e){
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"Eroare!",e.getMessage());

        }


    }
}
