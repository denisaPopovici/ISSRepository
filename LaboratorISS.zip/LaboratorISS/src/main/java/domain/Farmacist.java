package domain;

public class Farmacist extends Entity<Integer>{
    private String nume;
    private String username;
    private String parola;
    private String dataNasterii;
    private Integer idFarmacie;

    public Farmacist(){}

    public Farmacist(String nume, String username, String parola, String dataNasterii, Integer idFarmacie) {
        this.nume = nume;
        this.username = username;
        this.parola = parola;
        this.dataNasterii = dataNasterii;
        this.idFarmacie = idFarmacie;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(String dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public Integer getIdFarmacie() {
        return idFarmacie;
    }

    public void setIdFarmacie(Integer idFarmacie) {
        this.idFarmacie = idFarmacie;
    }

    @Override
    public String toString() {
        return "Farmacist{" + "id='" + getId()+ '\''+
                ", nume='" + nume + '\'' +
                ", username='" + username + '\'' +
                ", parola='" + parola + '\'' +
                ", dataNasterii='" + dataNasterii + '\'' +
                ", idFarmacie='" + idFarmacie + '\'' +
                '}';
    }
}
