package domain;

public class Medicament extends Entity<Integer>{
    private String nume;
    private float pret;
    private String companie;
    private int eficacitate;

    public Medicament(){}

    public Medicament(String nume, float pret, String companie, int eficacitate) {
        this.nume = nume;
        this.pret = pret;
        this.companie = companie;
        this.eficacitate = eficacitate;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getCompanie() {
        return companie;
    }

    public void setCompanie(String companie) {
        this.companie = companie;
    }

    public int getEficacitate() {
        return eficacitate;
    }

    public void setEficacitate(int eficacitate) {
        this.eficacitate = eficacitate;
    }

    @Override
    public String toString() {
        return "Medicament{" + "id='" + getId()+ '\''+
                ", nume='" + nume + '\'' +
                ", pret='" + pret + '\'' +
                ", companie='" + companie + '\'' +
                ", eficacitate='" + eficacitate + '\'' +
                '}';
    }
}
