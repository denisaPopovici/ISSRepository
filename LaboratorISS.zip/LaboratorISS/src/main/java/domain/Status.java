package domain;

public enum Status {
    InAsteptare, Onorata, Anulata
}
