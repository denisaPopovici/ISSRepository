package domain;

public class CadruMedical extends Entity<Integer>{
    private String nume;
    private String username;
    private String parola;
    private String dataNasterii;
    private Integer idSectie;

    public CadruMedical(){}

    public CadruMedical(String nume, String username, String parola, String dataNasterii, Integer idSectie) {
        this.nume = nume;
        this.username = username;
        this.parola = parola;
        this.dataNasterii = dataNasterii;
        this.idSectie = idSectie;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(String dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public Integer getIdSectie() {
        return idSectie;
    }

    public void setIdSectie(Integer idSectie) {
        this.idSectie = idSectie;
    }

    @Override
    public String toString() {
        return "Personal medical{" + "id='" + getId()+ '\''+
                ", nume='" + nume + '\'' +
                ", username='" + username + '\'' +
                ", parola='" + parola + '\'' +
                ", dataNasterii='" + dataNasterii + '\'' +
                ", idSectie='" + idSectie + '\'' +
                '}';
    }
}
