package domain;

public class DTOStoc {
    private String nume;
    private float pret;
    private String companie;
    private int eficacitate;
    private int cantitate;

    public DTOStoc(String nume, float pret, String companie, int eficacitate, int cantitate) {
        this.nume = nume;
        this.pret = pret;
        this.companie = companie;
        this.eficacitate = eficacitate;
        this.cantitate = cantitate;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getCompanie() {
        return companie;
    }

    public void setCompanie(String companie) {
        this.companie = companie;
    }

    public int getEficacitate() {
        return eficacitate;
    }

    public void setEficacitate(int eficacitate) {
        this.eficacitate = eficacitate;
    }

    public int getCantitate() {
        return cantitate;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }
}
