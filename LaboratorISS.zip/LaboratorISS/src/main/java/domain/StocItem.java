package domain;

public class StocItem extends Entity<Integer>{
    private int cantitate;
    private Integer idFarmacie;
    private Integer idMedicament;

    public StocItem(){
    }

    public StocItem(Integer idFarmacie, Integer idMedicament, int cantitate) {
        this.idFarmacie=idFarmacie;
        this.idMedicament=idMedicament;
        this.cantitate = cantitate;
    }

    public Integer getIdFarmacie() {
        return idFarmacie;
    }

    public void setIdFarmacie(Integer idFarmacie) {
        this.idFarmacie = idFarmacie;
    }

    public Integer getIdMedicament() {
        return idMedicament;
    }

    public void setIdMedicament(Integer idMedicament) {
        this.idMedicament = idMedicament;
    }

    public int getCantitate() {
        return cantitate;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

    @Override
    public String toString() {
        return "ComandaItem{" + "id='" + getId()+ '\''+
                ", cantitate='" + cantitate + '\'' +
                '}';
    }
}
