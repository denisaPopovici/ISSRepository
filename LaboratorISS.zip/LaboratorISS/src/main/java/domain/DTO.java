package domain;

public class DTO {
    private Integer idComanda;
    private String data;
    private String status;
    private int cantitate;
    private String descriere;
    private String medicament;

    public DTO(String data, String status, int cantitate, String descriere, String medicament) {
        this.data = data;
        this.status = status;
        this.cantitate = cantitate;
        this.descriere = descriere;
        this.medicament = medicament;
    }

    public String getData() {
        return data;
    }

    public Integer getIdComanda() {
        return idComanda;
    }

    public void setIdComanda(Integer idComanda) {
        this.idComanda = idComanda;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCantitate() {
        return cantitate;
    }

    public void setCantitate(int cantitate) {
        this.cantitate = cantitate;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public String getMedicament() {
        return medicament;
    }

    public void setMedicament(String medicament) {
        this.medicament = medicament;
    }
}
