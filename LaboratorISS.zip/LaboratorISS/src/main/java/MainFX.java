import controller.LogInController;
import domain.Comanda;
import domain.Medicament;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import repository.*;
import service.Service;

import java.time.LocalDate;

public class MainFX extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/views/LogInView.fxml"));
        AnchorPane root = loader.load();

        LogInController ctrl = loader.getController();

        Medicament medicament=new Medicament("Ibuprofen",25,"HA",100);

        CadruMedicalRepository cadruMedicalRepository = new CadruMedicalRepositoryHibernate();
        ComandaRepository comandaRepository=new ComandaRepositoryHibernate();
        FarmacieRepository farmacieRepository=new FarmacieRepositoryHibernate();
        FarmacistRepository farmacistRepository=new FarmacistRepositoryHibernate();
        MedicamentRepository medicamentRepository=new MedicamentRepositoryHibernate();
        SectieRepository sectieRepository=new SectieRepositoryHibernate();
        StocItemRepository stocItemRepository=new StocItemRepositoryHibernate();
        System.out.println(medicamentRepository.findAll());

        Service serv=new Service(cadruMedicalRepository,comandaRepository,farmacieRepository,farmacistRepository,medicamentRepository,sectieRepository,stocItemRepository);

        ctrl.setService(serv);

        Comanda comanda=new Comanda(LocalDate.now().toString(), "In asteptare", 2, "acum", 1, 1);
        //comandaRepository.save(comanda);
        comanda.setStatus("Anulata");
        comanda.setId(7);
        comandaRepository.update(comanda);

        primaryStage.setScene(new Scene(root, 700, 500));
        primaryStage.setTitle("Log in:");
        primaryStage.show();
//        Farmacie farmacie=new Farmacie("Catena", 400);
//        FarmacieRepository farmacieRepository=new FarmacieRepositoryHibernate();
//        farmacieRepository.save(farmacie);
//
//        Farmacist farmacist=new Farmacist("Denisa","pdir2800","parola0", LocalDate.of(1999,12,27), 1);
//        System.out.println(farmacist);
//        FarmacistRepository farmacistRepository=new FarmacistRepositoryHibernate();
//        farmacistRepository.save(farmacist);
//
//        System.out.println(farmacistRepository.findOne(1));
//
//        System.out.println(farmacieRepository.findAll());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
