package repository;

import domain.StocItem;
import domain.Tuple;

public interface StocItemRepository extends CrudRepository<Integer, StocItem>{
    public StocItem findByIDs(Integer idFarmacie, Integer idMedicament);
}
