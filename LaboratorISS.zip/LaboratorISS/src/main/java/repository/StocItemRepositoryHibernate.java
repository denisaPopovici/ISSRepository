package repository;

import domain.CadruMedical;
import domain.Comanda;
import domain.StocItem;
import domain.Tuple;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class StocItemRepositoryHibernate implements StocItemRepository {
    @Override
    public StocItem findOne(Integer id) throws IllegalArgumentException {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from StocItem where id=:id");
            query.setParameter("id", id);
            StocItem stocItem= (StocItem) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  stocItem;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }

    @Override
    public Iterable<StocItem> findAll() {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            //Query query=session.createQuery("from "Angajat" ");
            //List<Angajat> angajati= query.getResultList();
            List<StocItem> items =
                    session.createQuery("from StocItem", StocItem.class)
                            .list();
            session.getTransaction().commit();
            close();
            return  items;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }


    @Override
    public void save(StocItem entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                StocItem stocItem= new StocItem(entity.getIdFarmacie(), entity.getIdMedicament(), entity.getCantitate());
                session.save(stocItem);
                tx.commit();
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(StocItem e) {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from StocItem where idFarmacie=:idF and idMedicament=:idM");
            query.setParameter("idF", e.getIdFarmacie());
            query.setParameter("idM", e.getIdMedicament());
            StocItem stocItem= (StocItem) query.uniqueResult();
            stocItem.setCantitate(e.getCantitate());
            session.getTransaction().commit();
            close();
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
            close();
        }
    }

    static SessionFactory sessionFactory;
    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }

    @Override
    public StocItem findByIDs(Integer idFarmacie, Integer idMedicament) {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from StocItem where idMedicament=:idM and idFarmacie=:idF");
            query.setParameter("idM", idMedicament);
            query.setParameter("idF", idFarmacie);
            StocItem stocItem= (StocItem) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  stocItem;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }
}
