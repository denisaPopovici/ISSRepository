package repository;

import domain.CadruMedical;
import domain.Medicament;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import java.util.List;

public class MedicamentRepositoryHibernate implements MedicamentRepository{
    @Override
    public Medicament findOne(Integer id) throws IllegalArgumentException {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            Query query=session.createQuery("from Medicament where idMedicament=:id");
            query.setParameter("id", id);
            Medicament medicament= (Medicament) query.uniqueResult();
            session.getTransaction().commit();
            close();
            return  medicament;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }

    @Override
    public Iterable<Medicament> findAll() {
        initialize();
        try(Session session= sessionFactory.openSession()){
            session.beginTransaction();
            //Query query=session.createQuery("from "Angajat" ");
            //List<Angajat> angajati= query.getResultList();
            List<Medicament> medicamente=
                    session.createQuery("from Medicament",Medicament.class)
                            .list();
            session.getTransaction().commit();
            close();
            return  medicamente;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            close();
        }
        return null;
    }


    @Override
    public void save(Medicament entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Medicament medicament = new Medicament(entity.getNume(), entity.getPret(), entity.getCompanie(), entity.getEficacitate());
                session.save(medicament);
                tx.commit();
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public void update(Medicament e) {

    }

    static SessionFactory sessionFactory;
    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exception "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close(){
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }

    }
}
