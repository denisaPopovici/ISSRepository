package repository;

import domain.Comanda;

public interface ComandaRepository extends CrudRepository<Integer, Comanda> {
}
