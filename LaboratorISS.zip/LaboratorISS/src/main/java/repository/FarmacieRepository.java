package repository;

import domain.Farmacie;

public interface FarmacieRepository extends CrudRepository<Integer, Farmacie> {
}
