package repository;

import domain.CadruMedical;

public interface CadruMedicalRepository extends CrudRepository<Integer, CadruMedical>{
}
