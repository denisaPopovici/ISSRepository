package controller;

import domain.Entity;
import domain.Farmacist;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.hibernate.service.spi.ServiceRegistryAwareService;
import service.Service;

import java.io.IOException;

public class MainWindowControllerPharmacist {
    private Service service;
    private Farmacist currentUser;

    public void setService(Service service) {
        this.service=service;
    }

    public void setCurrentUser(Farmacist currentUser){
        System.out.println(currentUser);
        this.currentUser=currentUser;
    }

    @FXML
    private void initialize() {
    }

    @FXML
    public void vizualizeazaComenzi() {
        try {

            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/views/CommandsPharmacistView.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            ViewCommandsControllerPharmacist mainController = loader.getController();
            mainController.setService(service);
            mainController.setCurrentUser(currentUser);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void vizualizeazaStoc() {
        try {

            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/views/CheckStockView.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            CheckStockController mainController = loader.getController();
            mainController.setCurrentUser(currentUser);
            mainController.setService(service);
            System.out.println("setez user:"+currentUser);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
