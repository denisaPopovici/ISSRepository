package controller;

import domain.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import service.Service;
import utils.observer.Observer;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class CheckStockController implements Observer {
    private Service service;
    private Farmacist currentUser;

    public void setCurrentUser(Farmacist currentUser){
        System.out.println(currentUser);
        this.currentUser=currentUser;
    }

    public void setService(Service service) {
        this.service=service;
        initModel();
        service.addObserver(this);
    }

    ObservableList<DTOStoc> model = FXCollections.observableArrayList();

    @FXML
    TableView<DTOStoc> tableView;
    @FXML
    TableColumn<DTOStoc, String> tableColumnNume;
    @FXML
    TableColumn<DTOStoc, Float> tableColumnPret;
    @FXML
    TableColumn<DTOStoc, String> tableColumnCompanie;
    @FXML
    TableColumn<DTOStoc, Integer> tableColumnEficacitate;
    @FXML
    TableColumn<DTOStoc, Integer> tableColumnCantitate;

    @FXML
    public void initialize() {
        tableColumnNume.setCellValueFactory(new PropertyValueFactory<DTOStoc, String>("nume"));
        tableColumnPret.setCellValueFactory(new PropertyValueFactory<DTOStoc, Float>("pret"));
        tableColumnCompanie.setCellValueFactory(new PropertyValueFactory<DTOStoc, String>("companie"));
        tableColumnEficacitate.setCellValueFactory(new PropertyValueFactory<DTOStoc, Integer>("eficacitate"));
        tableColumnCantitate.setCellValueFactory(new PropertyValueFactory<DTOStoc, Integer>("cantitate"));

        tableView.setItems(model);
    }

    private void initModel() {
        System.out.println(currentUser);
        List<DTOStoc> list = StreamSupport.stream(service.getAllStocItems().spliterator(), false)
                .filter(x -> (x.getIdFarmacie() == currentUser.getIdFarmacie()))
                .map(x->{
                    DTOStoc dto=new DTOStoc(service.findMedicament(x.getIdMedicament()).getNume(),service.findMedicament(x.getIdMedicament()).getPret(), service.findMedicament(x.getIdMedicament()).getCompanie(), service.findMedicament(x.getIdMedicament()).getEficacitate(), x.getCantitate());
                    return dto;})
                .collect(Collectors.toList());
        model.setAll(list);
    }

    @Override
    public void update() {
        initModel();
    }
}
