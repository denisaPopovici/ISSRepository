package service;

import domain.*;

import java.util.List;

public interface IService {
    public Farmacist getFarmacistByUsernameAndPassword(String username, String parola);

    public CadruMedical getCadruMedicalByUsernameAndPassword(String username, String parola);

    public Iterable<Medicament> getAllMedicamente();

    public Iterable<Comanda> getAllComenzi();

    public void addComanda(Medicament medicament, int cantitate, String descriere, Integer idSectie);

    public Medicament findMedicament(Integer id);

    void updateComanda(Comanda comanda, String status, Integer idFarmacie);

    public Comanda findComanda(Integer id);

    public Iterable<StocItem> getAllStocItems();

    public int findStoc(Integer idFarmacie, Integer idMedicament);


}
